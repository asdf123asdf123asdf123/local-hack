#include <bits/stdc++.h>
using namespace std;
random_device R;
mt19937 G(R());
long long rand(long long l,long long r){
	return uniform_int_distribution<long long>(l,r)(G);
}
int main(){
	freopen("case.text","r",stdin);
	int x;
	cin>>x;
	if(x<=5)
		cout<<rand(1,10)<<" "<<rand(1,10);
	else
		cout<<rand(1,1000000000000000000)<<" "<<rand(1,1000000000000000000);
	return 0;
}
