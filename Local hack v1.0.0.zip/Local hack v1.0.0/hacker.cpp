#include<bits/stdc++.h>
#include<windows.h>
#include<graphics.h>
using namespace std;
int notepad,hacktime=2147483647,skipped,maxms;
string gplusplus,option,font,checker,report;
void quick_quit(){
	while(is_run());
	skipped=1;
	closegraph();
}
void skip(){
	while(1)
		if(keystate(key_esc)){
			getch();
			system("taskkill /f /im std.exe");
			system("taskkill /f /im gen.exe");
			system("taskkill /f /im user.exe");
			system("taskkill /f /im checker.exe");
			system("taskkill /f /im commander.exe");
			system("del report");
			system("del case.text");
			system("del checker.exe");
			system("del gen.exe");
			system("del std.exe");
			system("del user.exe");
			system("del test.in");
			system("del test.out");
			system("del user.out");
			exit(0);
			return;
		}
}
void hc(){
	HWND h=GetForegroundWindow();
	ShowWindow(h,SW_HIDE);
}
void mkexe(string s){
	string command="\""+gplusplus+"\" -o "+s+".exe "+s+".cpp "+option;
	system(command.c_str());
}
int ready;
void initexe(){
	mkexe("std");
	ready=1;
	mkexe("user");
	ready=2;
	mkexe("gen");
	ready=3;
	mkexe("checker");
	ready=4;
}
void draw(){
	setcolor(0x000000);
	setfont(50,0,font.c_str());
	xyprintf(25,25,"Preparing for the hack...");
	setfont(25,0,font.c_str());
	xyprintf(25,75,"Loding standard code...");
	if(ready>=1){
		xyprintf(25,100,"Loding wrong code...");
		if(ready>=2){
			xyprintf(25,125,"Loding generator...");
			if(ready>=3){
				xyprintf(25,150,"Loding checker...");
				if(ready==4){
					setcolor(0x00ff00);
					setfont(50,0,font.c_str());
					xyprintf(25,175,"Ready!");
				}
			}
		}
	}
}
void init(){
	ifstream setup("setup.inf");
	if(!setup){
		MessageBox(NULL,"û�������ļ�","����",MB_OK+16);
		exit(-1);
	}
	system("taskkill /f /im std.exe");
	system("taskkill /f /im gen.exe");
	system("taskkill /f /im user.exe");
	system("taskkill /f /im checker.exe");
	getline(setup,gplusplus);
	getline(setup,option);
	getline(setup,font);
	setup>>maxms;
	if(setup.eof())
		notepad=1;
	else{
		setup>>hacktime;
		if(setup.eof())
			notepad=1;
		else
			setup>>notepad;
	}
	thread genexe(initexe);
	genexe.detach();
	initgraph(1,1,INIT_NOFORCEEXIT|INIT_RENDERMANUAL);
	setcaption("Local hack 1.0.0");
	setcolor(0xFFFFFF);
	setbkcolor(0xFFFFFF);
	setbkmode(TRANSPARENT);
	for(int i=1;i<=640;i++,delay_fps(200)){
		resizewindow(i,1);
		cleardevice();
		draw();
	}
	for(int i=1;i<=480;i++,delay_fps(200)){
		resizewindow(640,i);
		cleardevice();
		draw();
	}
	while(delay_fps(30),ready!=4){
		cleardevice();
		draw();
	}
}
int commander(string command,string backup,int time){
	string need="commander.exe \""+command+"\" \""+backup+"\" "+to_string(time);
	return system(need.c_str());
}
int startjudge(){
	int rp;
	rp=commander("gen.exe > test.in","taskkill /f /im gen.exe",5000);
	if(rp==123321){
		report="Generator time limit exceeded.";
		return 2;
	}
	if(rp){
		report="Generator runtime error.";
		return 2;
	}
	rp=commander("std.exe < test.in > test.out","taskkill /f /im std.exe",5000);
	if(rp==123321){
		report="Std time limit exceeded.";
		return 2;
	}
	if(rp){
		report="Std runtime error.";
		return 2;
	}
	rp=commander("user.exe < test.in > user.out","taskkill /f /im user.exe",maxms);
	if(rp==123321){
		report="Time limit exceeded.";
		return 1;
	}
	if(rp){
		report="Runtime error.";
		return 1;
	}
	return 0;
}
int aced=0,used=0;
double point=0;
int judger(){
	int res;
	setfont(50,0,font.c_str());
	setcolor(0x808080);
	for(int casesum=1;casesum<=hacktime;casesum++){
		cleardevice();
		xyprintf(25,25,"Running on hack %d",casesum);
		delay_fps(30);
		ofstream testcase("case.text");
		testcase<<casesum;
		testcase.close();
		res=startjudge();
		if(!res){
			int rp=commander("checker.exe","taskkill /f /im checker.exe",5000);
			if(rp==123321){
				report="Checker time limit exceeded.";
				return 2;
			}
			if(rp){
				report="Checker runtime error.";
				return 2;
			}
			ifstream rep("report");
			rep>>res;
			getline(rep,report);
			getline(rep,report);
			if(res==0)
				return 1;
		}
		else
			return res;
	}
	return 0;
}
void judge(){
	int done=judger();
	system("del report");
	system("del case.text");
	system("del checker.exe");
	system("del gen.exe");
	system("del std.exe");
	system("del user.exe");
	cleardevice();
	setfont(40,0,font.c_str());
	if(done==0){
		setcolor(0x0000A0);
		xyprintf(25,25,"Unsuccessful hacking attempts");
	}
	if(done==1){
		setcolor(0xFF0000);
		system("ren test.in hack.in");
		system("ren test.out hack.out");
		system("ren user.out wrong.out");
		xyprintf(25,25,"Successful hacking attempt");
	}
	if(done==2){
		setcolor(0x808080);
		system("ren test.in hack.in");
		system("ren test.out hack.out");
		system("ren user.out wrong.out");
		xyprintf(25,25,"Hacking error");
	}
	system("del test.in");
	system("del test.out");
	system("del user.out");
	setcolor(0xFFFFFF);
	setfont(25,0,font.c_str());
	xyprintf(25,75,"%s",report.c_str());
	delay_fps(30);
	while(is_run());
}
int main(){
	thread quick(quick_quit);
	quick.detach();
	hc();
	init();
	thread skipping(skip);
	skipping.detach();
	judge();
	return 0;
}
